Notes:
=====

1) Our proof of conecpt is a video presenting running one of the algorithms in the system that we created.
The very good news of our project is that all of the algorithms are running using our web-application! :)
But, for keeping the POC nice, easy to understand and short (because some algorithms runs for 5 minutes and more), 
the video contains only the run of one of the algorithms.

2) ADD and ARD attached are updated.

Thanks!
Group 2 - MolOptimizer Group.

