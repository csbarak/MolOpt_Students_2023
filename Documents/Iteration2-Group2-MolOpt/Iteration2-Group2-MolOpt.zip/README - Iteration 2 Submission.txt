Group 2 - MolOptimizer Group
============================

Student in the group:
- Amit Peled (315530949)
- Daniel Piro (311434526)
- Shahar Alon (315570465)
- Nofar Rozenberg (313294092)